README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. Justin Paddock, LEC 001, jpaddock@wisc.edu
2. Rishi Patel, LEC 001, rpatel46@wisc.edu
3. Nate Smith, LEC 001, nvsmith@wisc.edu
4. Mohamed Alremeithi, LEC 001, malremeithi@wisc.edu
5. Jake Wesson, LEC 001, jwesson@wisc.edu

Notes:
Justin and Mohamed on same xteam. Every other member on separate xteams.